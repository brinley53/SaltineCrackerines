<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="http://saltine.wuaze.com/styles/home_styles.css?v=<? echo time(); ?>">
</head>
<body>

    
    <div class="main">
        <h1 style="margin-left: 2vw"> Pokemon Team Creator </h1>
        <div class="home_img">
            <a href="./createuser.php"><img src="images/homepikachu.png"></a>
        </div>
    </div>


</body>
</html>